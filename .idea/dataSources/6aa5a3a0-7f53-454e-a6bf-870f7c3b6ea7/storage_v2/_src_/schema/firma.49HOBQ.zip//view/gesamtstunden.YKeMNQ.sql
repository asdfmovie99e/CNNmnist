create view gesamtstunden as
  select
    `firma`.`arbeitet_an`.`PNR`          AS `PNR`,
    sum(`firma`.`arbeitet_an`.`Stunden`) AS `SUM(Stunden)`
  from `firma`.`arbeitet_an`
  group by `firma`.`arbeitet_an`.`PNR`;

